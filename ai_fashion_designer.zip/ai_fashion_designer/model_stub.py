
# model_stub.py
# A simple rule-based placeholder that 'analyzes' an image filename and returns suggestions.
# Replace this file with actual model inference code (OpenAI, TensorFlow, etc.)
import os

def suggest_outfits(image_path: str):
    # Very small heuristic: look at filename keywords for style hints
    name = os.path.basename(image_path).lower()
    suggestions = []
    if 'formal' in name or 'suit' in name:
        suggestions = [
            {'title':'Monochrome Formal', 'description':'Tailored look with neutral tones', 'asset':'assets/outfit_formal.svg'},
            {'title':'Evening Blazer', 'description':'Layered blazer style for events', 'asset':'assets/outfit_evening.svg'}
        ]
    elif 'casual' in name or 'tshirt' in name or 'jeans' in name:
        suggestions = [
            {'title':'Casual Chic', 'description':'Comfortable layered casual with denim', 'asset':'assets/outfit_casual.svg'},
            {'title':'Streetwear Vibes', 'description':'Bold prints, sneakers, relaxed fit', 'asset':'assets/outfit_street.svg'}
        ]
    else:
        # generic suggestions
        suggestions = [
            {'title':'Smart Casual', 'description':'Mix of formal and casual pieces', 'asset':'assets/outfit_smart.svg'},
            {'title':'Seasonal Trend', 'description':'Colors and textures for the season', 'asset':'assets/outfit_trend.svg'}
        ]
    return suggestions
