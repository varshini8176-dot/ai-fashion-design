
from flask import Flask, render_template, request, redirect, url_for
from werkzeug.utils import secure_filename
import os
from model_stub import suggest_outfits

UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXT = {'png','jpg','jpeg','gif'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED_EXT

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    if 'photo' not in request.files:
        return redirect(url_for('index'))
    f = request.files['photo']
    if f.filename == '' or not allowed(f.filename):
        return redirect(url_for('index'))
    filename = secure_filename(f.filename)
    path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    f.save(path)
    suggestions = suggest_outfits(path)
    return render_template('results.html', image_path=path, suggestions=suggestions)

if __name__ == '__main__':
    app.run(debug=True)
